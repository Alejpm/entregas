<?php

    $json = "../json/entradas.json";
    $datos = file_get_contents($json);
    $datosjson = json_decode($datos);

    $rss = new SimpleXMLElement('<?xml version="1.0" encoding=UTF-8"?><rss version="2.0"></rss>
    ');
    $canal = $rss->addChild('channel');
    $canal->addChild('title','La web de Alejandro');
    $canal->addChild('lino','https://alejandro.com');
    $canal->addChild('description','Estudiante en Valencia, España');

    foreach($datosjson['entradas'] as $entrada){
        $elemento = $canal->addChild('item');
        $elemento->addChild('title',$entrada['titulo']);
        $elemento->addChild('descripcion',$entrada['texto']);
        $elemento->addChild('link', 'https://alejandro.com');
        $elemento->addChild('fecha',$entrada['fecha']);
    }
    
    //header('Content-type: application/rss+xml;charset=utf-8');
    //echo $rss->asXML();
    file_put_contents('entradas.rss',$rss-asXML());
?>