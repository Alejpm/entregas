fetch("json/005-entradas.json")
    .then(response => response.json())
    .then(function(response){
        // Selecciono a la etiqueta
        var seccion = document.querySelector("section")
        // Vacio la seccion
        seccion.innerHTML = ""
        console.log(response);
        for(let i = 0; i < response.entradas.length; i++){
            seccion.innerHTML += `
                <article>
                    <h4>` + response.entradas[i].título + `</h4>
                    <time>` + response.entradas[i].fecha + `</time>
                    <p>` + response.entradas[i].texto + `</p>
                </article>
            `;
        }
    });
