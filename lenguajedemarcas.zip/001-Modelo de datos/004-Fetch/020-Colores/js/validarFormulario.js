var campos = document.getElementsByClassName("control")

for(var i = 0;i<campos.length;i++){
    campos[i].onblur = function(){
        console.log("Has salido de un campo")
        validarFormulario()
    }
}
function validarFormurlario(){
    console.log("En el nombre pone: ")
    console.log(document.getElementById("nombre").value)
    console.log("La longitud del campo es: ")
    console.log(document.getElementById("nombre").value.lenght)
    console.log("En el asunto pone: ")
    console.log(document.getElementById("asunto").value)
    console.log("La longitud del campo es: ")
    console.log(document.getElementById("asunto").value.lenght)
    console.log("En el email pone: ")
    console.log(document.getElementById("email").value)
    console.log("La longitud del campo es: ")
    console.log(document.getElementById("email").value.lenght)
    console.log("En el mensaje pone: ")
    console.log(document.getElementById("mensaje").value)
    console.log("La longitud del campo es: ")
    console.log(document.getElementById("mensaje").value.lenght)
    if(
        document.getElementById("nombre").value.lenght > 5
        &&
        document.getElementById("asunto").value.lenght > 5
        &&
        document.getElementById("email").value.lenght > 5
        
        
    ){
        console.log("Te voy a dejar enviar el mensaje ")
        document.getElementById("botonEnviar").removeAttribute("disabled")
}else{
    console.log("No te voy a dejar enviar el mensaje ")
    document.getElementById("botonEnviar").setAttribute("disabled",true)
    
    
    }
        

}