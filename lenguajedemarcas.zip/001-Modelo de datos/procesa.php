<?php


    $rss = new SimpleXMLElement('<?xml version="1.0" encoding=UTF-8" ?><formulario></formulario>');
    $rss->addChild('nombre','');
    $rss->addChild('asunto','');
    $rss->addChild('email','');
    $rss->addChild('mensaje','');  
    
    file_put_contents('formmularios/'.date('Y').date('m').date('d').date('H').date('i').date('s').' xml',$rss->asXML());
    echo "Formulario guardado";
?>