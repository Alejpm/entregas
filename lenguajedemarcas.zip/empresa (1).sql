-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-06-2024 a las 13:32:16
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `empresa`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarCodigoProvincia` ()   BEGIN

UPDATE
codigospostales
SET idprovincia = LEFT(codigopostal,2)
WHERE idprovincia = '';

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarPagado` (IN `cantidadpagado` INT)   BEGIN
	UPDATE pedidos
	SET pagado = cantidadpagado;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `Identificador` int(255) NOT NULL,
  `nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`Identificador`, `nombre`) VALUES
(1, 'Físico');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `Identificador` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `idfiscal` varchar(50) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `codigopostal` varchar(20) NOT NULL,
  `nombrepersonacontacto` varchar(250) NOT NULL,
  `emailpersonacontacto` varchar(100) NOT NULL,
  `imagen` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='En esta tabla guardaremos los usuarios';

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`Identificador`, `nombre`, `idfiscal`, `direccion`, `codigopostal`, `nombrepersonacontacto`, `emailpersonacontacto`, `imagen`) VALUES
(3, 'Nombre de la empresa 1', 'C000001', 'Dirección de la empresa 1', '46001', 'Juan Lopez Martinez', 'juanlopez@empresa1.com', 0xffd8ffe000104a46494600010100000100010000ffdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc200110800c800c803012200021101031101ffc4001d000101010003010101010000000000000000070804050603020109ffc400190101010101010100000000000000000000000102040305ffda000c03010002100310000001920fa3e60000000000000000000000517d2506b5cbacc8d36cdcc8d3633234d8cc8d3633234d8c47e5ec71ceac06800000006aaad496b5c3bcc1c19f753d59aba50b2ae940aba5034bdb7296ade5de5e8e58e39d590dc000000035556a4b5ae1de11a6ccaadd59d05e63def94e4d63adb589f777b4ea712ef0c2250756e52d5b865e8e58e39d303700000000d555a92d6b877846ad29ab75674c794f57e538f58f377611dddef184777611283ab7296adc32f472c71ce981b800000006aaad496b5c3bc235694fcfaf1bcbca651f878eb83bbbfcff00f4fe936ce11ed7cc153d5b94b56f85cbd1cb1c73a606e00000001aaab525ad70ef12f57bb9e9308b772b08b770c22ddc333e983c6e5e8e58e39d990dc00000002dfeef2abcaeaa65546aa6551aa99546aa6551aa99545067c7ac0a00000028ddbe122684e766e6d53fd3690a5f38f10b691466e57fd856705d3aa240bafa43330f4800000149f71e1fb6f1b31aef6dd8479988d4bd1e9f088dff00891f3fcf33afcd8b5ee076df49ceec78df8f2b9fee1f5e6ee67d1ed000000342c1b87f7c3f7c8a1f632c9be7eb7d554b7f950fbc4c38549ea2cf1ffda57d1665f6a875d137f9d83aaa978dc000000000000000000000000000000000000000000fffc40029100000040602010402030000000000000000020405030607173536013015101314163750203460ffda0008010100010502fdc30c94a5fd15ae5c2d72e16b970b5cb85ae5c2d72e16b970b5cb85ae5c2d72e16b9707f608b2f29eca69af75d4ecbf6534d782fa8aec9d75cb78172de05cb78172de05cb78172de05cb781264e6b1f5c854ecbf6534d783b657f9d34d9054ecbf6534d783b656992682a5cfc4a1133b6a4852f35978339f89423c4a10e85e0ae74d364153b2fd94d35e0ed95a5795135eb6d395f476cad34d9054ecbf6534d783b65695e544d7adb4e57d1db2b4d364153b2fd94d35e0ed95a5795135eb6d395f476cad34d9054ecbf6534d783b65695e544d7adb4e57d1db2b4d364153b2fd94d35e0ed9542e4a9b4ff006b7811e64745304873423fdade07dade01ce68a7a69b20a9d97eca69af0746b5a673f12b87895c3c4ae1e2570f12b87895c3c4ae14e5ad5407b153b2fd94d35eeba9d97ec93a7142c4d572da45cb69172da45cb69172da45cb69172da45cb69172da45cb69172da44e6fa9df97fef29f9783cd0decd05e27b709f5135ac4ca1ba7c6b9119133aad35454700ccbf0a6770b909a172e4e90dfa436a337a4905ca7986e681cdd104882e6904aade9a657d3545469cfe6614c72874d3cda656dfdc7214bff00b54ff0e252d3020fc5eb7f1703cc52f4c89d3b4c9eeb1659693b27a4b1a274d3cda5bdde1334fae14fd339ac4a910c84d721bd266c566a6d0231994a8e595d6d2144e78825454f969cb6c441a6bef414121a56858826f45126b35364f1ccde90ad52b74b1165f95e12c52658aca9631f92b6aa3a73a2510a2709a3189c205263f289414de29683a78b0e2fc68dee7c48fecc5471e018adaace3e34605847393aa0fb7eefd8117103ed882287e7722a71e26b430152698d24052966b450396e9a0904f0dde0c09810cc88db234598d01102a9a902b5aa666831ca799dad4c442eed4d887fc87fffc4001b11000301000301000000000000000000000001113010204050ffda0008010301013f01f042108426a879218879218878d10c43c21084e1f7a5294a5ce7dbffc400231100020103050100030100000000000000000102111232031320315121404161d1ffda0008010201013f01fc096a49337246e48dc91b92372445d5579cf265912c8f8591f0b23e1a8a8fe10c79cf264b01766a9a46ae4431e73c992c05d9adfa348d5c8863ce7931aac682d264e171085a6ae4431e73c99ba6e9ba6e9295cea431e6f4d3fa6d44da89b5136a26d444a9f393950bdf6d0e5f689173f0bff85cfc2e6bb45cfce52ed8e49aa22b6b7514926ea7fa4e9fb3be89493eb9254fa55f855957e15655f855f855f9f9dfffc4004410000102030307080608040700000000000201030004111221730510133134b1c1223041519293a1e11423324471830635617281a2b2c24250829115525360d1e2f0ffda0008010100063f02fe71e92d3edb6369468558da98f18da98f18da98f18da98f18da98f18da98f18da98f18da98f18da98f18da98f18da98f18065d705c521b550e75714b87392f87c79d5c52e19a61a1d059070852a1f6fc63ddfbbf38f77eefce3ddfbbf38f77eefce3ddfbbf38f77eefce3ddfbbf385959a40f6149140699a5f0f8f3ab8a5c334e631efe63e4970cd2f87c79d5c52e19a7318f7c4da3cd03a88cea31af4c6c72fdd2465020956449195a2a3691288a9545782e5f8c6c72fdd246c72fdd244da225111e3b93e31f24b86697c3e3ceae2970cd398c7be273078e6ca38251278c1bf3ce631ef8f925c334be1f1e75714b8669cc63df13983c73651c12893c60df9e7318f7c7c92e19a5f0f8f3ab8a5c334e631ef89cc1e39b28e09449e306fcf398c7be3e4970cd2f87c79d5c52e19a7318f7c4e60f1cd94704a24f1837e79cc63df1f24b86697c3e3ceae2970cd398c7be08e55f3608928aa0b48fac663b706d3b3cf38d9a50854b5c098ad9215aa2a47d6331db8fac663b70464b68896aaab1f24b86697c3e3ceae2970cd36a928faa2bc77a36bd71b1cc774b1b1cc774b1b1cc774b1b1cc774b1b1cc774b1b1cc774b1b1cc774b0afbac1b4da3643cb154eacd2f87c79d5c52e1ce4be1f1e77d1e6349a4b6a5c91ac6a7fb1e71a9fec79c6a7fb1e71a9fec79c6a7fb1e71a9fec79c6a7fb1e71a9fec79c6a7fb1e71a9fec79c6a7fb1e70d3d2d6ac88516da53a7f9ecba12212593b97eec4d30f0d58070cc87ae9d10ecacae4969c6da2b36aa835fc2913a1e8232b38c8da151bfe17c4c3d3896a5a542da8aea5ffd485196c8ad689352a92257f2c4ee599d9516a5a51b1f5297a2adf7c28b3915a46fa39689fb627a71250258ad20d06ffe218929b9e9747c5b22240a7b456c9121e926f24b4c6952ca121eafcb12f24c64e09a7542d1ba4b45dcb1f53b5de7fd627a7a6da41966fd6ab5d17c284b6456b449a954906bf9632b4c7a1372cad8a8dd7f47c39a96fba7fa56329fccdf1358a5be328e0a6f8fa41849fa4f365dfc7f4e69fc5fdc31218dfbcf3305961b36a6db1a290a1708197969a741f3b87da4de91f49e4ccade8da1a175a593cd973fabf4f352ff0074ff004c4dbcfad9649c3022ea8766a572a362d3a56ecd2d53f1ac4eb853a33336f0d9144bbe1744ccbce158979b0b2a4ba935ff00cc294b658695ae8a8d78c4f6449e9a136269b4547b5256fba2ace58689be8e479c65596d22193730a35ebe58c488d52d69b57f59e603ff0015692d0a2d2c79c353737959a56d95b766966be319449e2b3233628d21aeab938df0a52d961a56ba2a35e31f48a4d5e1715b221b5aad72539a49f59fd3cd2b5ec56aa95d688890f3e571384a4b0882c992aa5a4a0f475c23e32ee932ab4b683756040d8700cbd91505aac29a346a09acacdc916125dd53a56cd85ad210558710956889616f8d8dfeed63446d98b9fe451be09bd11e906f51b37a423ba17344bfc76569fde045c65c6c8b5210aa5616ccabc545a2d1b5ba07d51f292d27275a75c11a012807b4489727361a55246ebcab3ae90928dcc4cb00d8b68932d8728acd6ea57ed8d2382e21692d0b681ec7acb5ed22de9f62a433352cfa9a82da4f5562cdf5eb58ab4d1fa3d822d1aa6b70891577521c229d9a7d0c4e8af37540b4a9752bf675c32dbb69f6c4dc734881654497d954bfe2919374efbca8cb2e83b5a972894a9d37eb4829bd2138d9028e9002ca85469544aaeaf8c1bd6a67283b641a437793c9ad57afecba16498d2a368d280bab5ff52d5295a6ae9869f2071058983785bd7a4bb93af55f1364db9312e732c80aa5aad93424aad7eea40a283d2e0c09b4d17b7c820b3aaea7478c1c80abd32d4cdad33d66c52ee4f26faff7ff0068ff00ffc400281000010204050501010101000000000000010011213151f0104161a1f1307191b1c1d1815060ffda0008010100013f21ff0060fe0addce1a8355c77e571df95c77e571df95c77e571df95c77e571df95c77e571df95c77e5373ac71845b3eadca9d46e3efd5b95304c5f9aec0804d0f2268791343c89a1e44d0f2268791343c89d813646d75c371f7eadca982ed5f4265f1c1b8fbf56e54c176ad3ad3802105b5574fc478be86905b22c84f86081c10d574fc574fc427c3000c007a997c706e3efd5b95305dab5b0fae176a2bb538ddab532f8e0dc7dfab72a60bb56b61f5c2ed4576a71bb56a65f1c1b8fbf56e54c176ad6c3eb85da8aed4e376ad4cbe38371f7eadca982ed5ad87d70bb515da9c6ed5a997c706e3efd5b95305dab511972c228b922713d2e4050a393093e0448ae48b922393293e24cca997c706e3efd5b95301dff00009821fa2ba7e2ba7e2ba7e2ba7e2ba7e2ba7e2ba7e2774448e9d430dc7dfab72a751b8fbf54fc6793662dae8b88a7114e229c45388a7114e229c45388a7114e228c493232771ff765ed00e264d185d8002841a908d1490e90816754b072040b170001e4c41430a226c1767d038a1bc118c215610794c7a90336022500f012d510868cc41fe0417c83b524676154ca0b01da03e7650f137898e8c4c6a512364eee1763d971d471c0bf779160599c0627f89f1498c0156107941a03706328bbb2bd3516da55e6b56ca90c5c3063e9897ef08058b88150e3628356397b8829a5912f1f126982628678c0f8385a68e90df665a205fa4c0f901161e9c170c4b02c1b3d32762c004e65c92873824e8103e8410745f88ca9814711a00e5406c8012896867a2248e46220770a63b60a10c564643429a3819e6652b87506c2b02e08889f951dc0dc4902681dd8e8c7997101814711a188601dc007e90a706840d0150651404c0343272e9bc110a5fe1aa6ba966937333f7829736d9d90d14f99902281372844b0c83ca99a48cee448090981d911b385e033f6529961d08e5059530bb31521374311d8b6853b1a59d8f355fb51750c26bbcd8a8130d354c1a4702ec9ce5d3121344e170ccc80384da1f192960ebc908779a8046230101e3239a20224539026f6c8f0d3bca7bec0001d145a13b52400bcd4599410363de040c09419c0f44f0988212e3664033829b659ba2dc6b0273da5406dfe118343c6281504c1d301ca183305125da40cc4248ca0e043443bf59297e99de6b07280b808011f34013399c4a218863969900b993fe47fffda000c03010002000300000010fbefbefbefbefbefbefbefbe1cc30c30cf7efbefbef9598f3cfdbcfbefbefbe554a56a97f3efbefbef9552b5285fcfbefbefbe557b15a57f3efbefbef9538c30cffcfbefbefbeb8f3cf3cff7efbefbeefed3acb6ebcfbefbefb92f5ece792bfefbefbeae2eae4d07b0fbefbefbefbefbefbefbefbefbefbefbefbefbefbefbffc4001f1100030002020301010000000000000000000111203110512140614171ffda0008010301013f10f4124208208207e1e6b4565656563546d9ad0b63e7d0db35a16c7ae7d0db35a138c81a0d4d0db35ac7d286d9d228a28a286ee5293e93b27de11764e88bbc90934eb255e069b5c2bf87f449ac9ba44444444444445ef7ffc40022110100020103050003000000000000000001001131102021304041516171e1f0ffda0008010201013f10ec1084fb4fb4fb4fb4fb4615d005071b00014c62e80cd1b4e6344a8d56f4317406698a6519ba18ba0382402371994c66aba18ba0061552fea5fd4bfa896262de92b7000069b8123e0b94181132152e68e52c16f2ba8850f26505aa27cbc3f3b8281ea79dd2bed2a2260ccb7fce2534aa8a846a7ee034bc9bad29b63e38681ad31636698eff004fffc400251001010002020104020203000000000000011100213151411030617150a1608140d1f0ffda0008010100013f10fcc0269424a976134f737efdfbf7efdfbf7efdec4fc0101c30369f88b9b6e073b78b6e1e4c0f63468d1a3468d1401d1584e356eafc5edb8df06db8dc1682660d00c679f47677f9fbb44287e4c29d06121447913c7abb7653a0c0420070078fe6f836dc6ecd86edf06db8dd9b0ddbe0db71bb361bb7c1b6e3766c376f836dc6f44a44d31a4f141f4d9f0c119f90f238c1a808b507b107d76d98350156547b557fc2c1b6e38f03225113613cfb0eddbb76eddbb57d8502c890a69fc46db9b50ccd5a31371bdbdcb972e5cb972e5cb972e171268a34017513f3af68dc69f0b8056f1e1bb041a27813ce20256d07a0902255acf18afda44445d8b213673ce5bf289d35da117980d298a548079c260be2bef06bd615c61a41b1145b3198d8209da807e2bf78ec54852f8bf7a4980d2e1bb6d361b6f5d59315906fe5110747673873b50455a34124a0207c6191d9f760828214d0b1a94c292405a70987d2bef0c6876aa4ba4787f5ef662c0089770bfe7efd21de3fd7fdfa7ea31730442441a27872901927976353b0e433e52b5f2c6681bde8a5ce1409846eac50a5d23ee628b85057e31e483fa8daa02a16742be30c56226d8014aaec138de431d8d601661e1281c796608ea4b066ce862961bc6c2e424b853af987d6233deef2cd851132c79c7fb45dc3c0c2bf24fa30106451449a58cbe7044e8a4c9d1cf9f4ef76359217a5cded928ec164041412f1ac9e3fc806d4de42f86cdb88d14865c29bed0fac8a8dcc6d6c3bedf69d5ae3428472792d16cde70811e93c1f56656f5ad7580de8f4c0ee07f088045fd9ae71974c49acdd5b758878d1e911084a5bc5cb6cdcbd08a7e5c614cf7458912a8450e2ef112b383bd161e5a17fac1c96ecd808b2ee935bb9f1908fcac34036a9c62ca6c0d69848adeb9e7588ee63ef42003b271d99cfa8d38f32d0528ef04408f8579743601a34472f39364522253a2f2fb6ac191d5362a0b38b9017dd82185c1378d23ac682d17446e414761d00228a3863f8b5fb48d71916e7d8219be642eaa6dc03a58a2a9211405903237272ba8dd265e955431014620d3bd54550041c588ce97012446ef6dc688e3634fa9fcc62a55160c4468087735240a2dc29ac1eded4c777b204cecac0c6ef08392d6a1111e57124e35136f20e5e2d15c8404200481cce3c2ef7c63cf7fc43ffd9),
(5, 'Nombre de la empresa 2', 'C000002', 'Dirección de la empresa 2', '46002', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `codigospostales`
--

CREATE TABLE `codigospostales` (
  `Identificador` int(255) NOT NULL,
  `idprovincia` varchar(255) NOT NULL,
  `codigopostal` varchar(6) DEFAULT NULL,
  `idmunicipio` int(5) DEFAULT NULL,
  `nombremunicipio` varchar(47) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `codigospostales`
--

INSERT INTO `codigospostales` (`Identificador`, `idprovincia`, `codigopostal`, `idmunicipio`, `nombremunicipio`) VALUES
(1, '46', '46055', 1, 'El pueblo de Jose Vicente'),
(2, '46', '46055', 1, 'El pueblo de Jose Vicente'),
(3, '46', '46056', 1, 'El segundo pueblo de Jose Vicente');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `detalle_pedidos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `detalle_pedidos` (
`Número de pedido` int(10)
,`Fecha del pedido` date
,`Nombre del cliente` varchar(150)
,`Total` decimal(42,2)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impuestos`
--

CREATE TABLE `impuestos` (
  `Identificador` int(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `tipoimpositivo` int(10) NOT NULL,
  `descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `impuestos`
--

INSERT INTO `impuestos` (`Identificador`, `nombre`, `tipoimpositivo`, `descripcion`) VALUES
(1, 'IVA 21%', 21, 'IVA general'),
(2, 'IVA 10%', 10, 'IVA reducido'),
(3, 'IVA 4%', 4, 'IVA super reducido'),
(4, 'IVA 21%', 21, 'IVA general'),
(5, 'IVA 10%', 10, 'IVA reducido'),
(6, 'IVA 4%', 4, 'IVA super reducido'),
(7, 'IVA 21%', 21, 'IVA general'),
(8, 'IVA 10%', 10, 'IVA reducido'),
(9, 'IVA 4%', 4, 'IVA super reducido'),
(10, 'IVA 0%', 0, 'IVA exento');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lineaspedido`
--

CREATE TABLE `lineaspedido` (
  `Identificador` int(10) NOT NULL,
  `pedidos_fecha` int(10) NOT NULL,
  `productos_nombre` int(10) NOT NULL,
  `cantidad` int(10) NOT NULL,
  `comentarios` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `lineaspedido`
--

INSERT INTO `lineaspedido` (`Identificador`, `pedidos_fecha`, `productos_nombre`, `cantidad`, `comentarios`) VALUES
(1, 1, 7, 3, ''),
(4, 1, 9, 1, ''),
(5, 1, 8, 2, ''),
(6, 2, 10, 2, ''),
(8, 2, 11, 2, ''),
(9, 2, 11, 2, ''),
(10, 2, 12, 2, ''),
(11, 2024001, 7, 1, '');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `listado_clientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `listado_clientes` (
`nombre` varchar(150)
,`idfiscal` varchar(50)
,`direccion` varchar(250)
,`nombremunicipio` varchar(47)
,`codigopostal` varchar(6)
,`provincia` varchar(22)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `Identificador` int(10) NOT NULL,
  `fecha` date NOT NULL,
  `clientes_nombre` int(10) NOT NULL,
  `impuestos_nombre` int(255) NOT NULL,
  `pagado` int(10) NOT NULL,
  `comentarios` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`Identificador`, `fecha`, `clientes_nombre`, `impuestos_nombre`, `pagado`, `comentarios`) VALUES
(1, '0000-00-00', 3, 0, 32, ''),
(2, '2023-12-20', 5, 0, 32, ''),
(2024001, '2023-12-20', 3, 2, 32, ''),
(2024002, '2024-06-12', 3, 21, 0, ''),
(2024003, '2024-06-12', 3, 21, 0, ''),
(2024005, '2024-01-31', 3, 21, 0, '');

--
-- Disparadores `pedidos`
--
DELIMITER $$
CREATE TRIGGER `eliminar_pedido` AFTER DELETE ON `pedidos` FOR EACH ROW BEGIN
	INSERT INTO registros VALUES(NULL,'DELETE',NOW(),'pedidos',OLD.Identificador);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertar_pedido` AFTER INSERT ON `pedidos` FOR EACH ROW BEGIN
	INSERT INTO registros VALUES(NULL,'INSERT',NOW(),'pedidos',NEW.Identificador,USER());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `Identificador` int(10) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `categorias_nombre` int(255) NOT NULL,
  `peso` decimal(10,2) NOT NULL,
  `imagen` mediumblob NOT NULL,
  `existencias` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='En esta tabla guardaremos los productos';

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`Identificador`, `nombre`, `descripcion`, `precio`, `categorias_nombre`, `peso`, `imagen`, `existencias`) VALUES
(7, 'Ratón', 'Ratón de ordenador', 15.50, 1, 0.00, 0x7261746f6e2e6a7067, 0),
(8, 'Teclado', 'Teclado de ordenador', 20.50, 1, 0.00, 0x7465636c61646f2e6a7067, 0),
(9, 'Monitor', 'Monitor de ordenador', 200.50, 1, 2.00, 0x6d6f6e69746f722e6a7067, 0),
(10, 'Curso', 'Curso de SQL paso a paso', 300.50, 1, 0.00, 0x637572736f73716c2e6a7067, 0),
(11, 'Curso de PHP', 'Curso de PHP paso a paso', 200.50, 1, 0.00, 0x637572736f7068702e6a7067, 0),
(12, 'Curso de Python', 'Curso de Python paso a paso', 400.50, 1, 0.00, 0x637572736f707974686f6e2e6a7067, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE `provincias` (
  `Identificador` int(255) NOT NULL,
  `codigo` varchar(2) DEFAULT NULL,
  `provincia` varchar(22) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`Identificador`, `codigo`, `provincia`) VALUES
(1, '02', 'Albacete'),
(2, '03', 'Alicante/Alacant'),
(3, '04', 'Almería'),
(4, '01', 'Araba/Álava'),
(5, '33', 'Asturias'),
(6, '05', 'Ávila'),
(7, '06', 'Badajoz'),
(8, '07', 'Balears, Illes'),
(9, '08', 'Barcelona'),
(10, '48', 'Bizkaia'),
(11, '09', 'Burgos'),
(12, '10', 'Cáceres'),
(13, '11', 'Cádiz'),
(14, '39', 'Cantabria'),
(15, '12', 'Castellón/Castelló'),
(16, '13', 'Ciudad Real'),
(17, '14', 'Córdoba'),
(18, '15', 'Coruña, A'),
(19, '16', 'Cuenca'),
(20, '20', 'Gipuzkoa'),
(21, '17', 'Girona'),
(22, '18', 'Granada'),
(23, '19', 'Guadalajara'),
(24, '21', 'Huelva'),
(25, '22', 'Huesca'),
(26, '23', 'Jaén'),
(27, '24', 'León'),
(28, '25', 'Lleida'),
(29, '27', 'Lugo'),
(30, '28', 'Madrid'),
(31, '29', 'Málaga'),
(32, '30', 'Murcia'),
(33, '31', 'Navarra'),
(34, '32', 'Ourense'),
(35, '34', 'Palencia'),
(36, '35', 'Palmas, Las'),
(37, '36', 'Pontevedra'),
(38, '26', 'Rioja, La'),
(39, '37', 'Salamanca'),
(40, '38', 'Santa Cruz de Tenerife'),
(41, '40', 'Segovia'),
(42, '41', 'Sevilla'),
(43, '42', 'Soria'),
(44, '43', 'Tarragona'),
(45, '44', 'Teruel'),
(46, '45', 'Toledo'),
(47, '46', 'Valencia/València'),
(48, '47', 'Valladolid'),
(49, '49', 'Zamora'),
(50, '50', 'Zaragoza'),
(51, '51', 'Ceuta'),
(52, '52', 'Melilla');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros`
--

CREATE TABLE `registros` (
  `Identificador` int(255) NOT NULL,
  `accion` varchar(255) NOT NULL,
  `tiempo` int(255) NOT NULL,
  `tabla` varchar(255) NOT NULL,
  `id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `registros`
--

INSERT INTO `registros` (`Identificador`, `accion`, `tiempo`, `tabla`, `id`) VALUES
(1, 'INSERT', 2147483647, 'pedidos', 2024004),
(2, 'DELETE', 2147483647, 'pedidos', 2024004),
(3, 'INSERT', 2147483647, 'pedidos', 2024005);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `totales_pedidos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `totales_pedidos` (
`Número de pedido` int(10)
,`Fecha del pedido` date
,`Nombre del cliente` varchar(150)
,`Total` decimal(42,2)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `Identificador` int(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `contrasena` varchar(50) NOT NULL,
  `nombrepropio` varchar(50) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `fotografia` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='En esta tabla guardaremos los usuarios';

-- --------------------------------------------------------

--
-- Estructura para la vista `detalle_pedidos`
--
DROP TABLE IF EXISTS `detalle_pedidos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `detalle_pedidos`  AS SELECT `pedidos`.`Identificador` AS `Número de pedido`, `pedidos`.`fecha` AS `Fecha del pedido`, `clientes`.`nombre` AS `Nombre del cliente`, sum(`productos`.`precio` * `lineaspedido`.`cantidad`) AS `Total` FROM (((`pedidos` left join `clientes` on(`pedidos`.`clientes_nombre` = `clientes`.`Identificador`)) left join `lineaspedido` on(`lineaspedido`.`pedidos_fecha` = `pedidos`.`Identificador`)) left join `productos` on(`lineaspedido`.`productos_nombre` = `productos`.`Identificador`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `listado_clientes`
--
DROP TABLE IF EXISTS `listado_clientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `listado_clientes`  AS SELECT `clientes`.`nombre` AS `nombre`, `clientes`.`idfiscal` AS `idfiscal`, `clientes`.`direccion` AS `direccion`, `codigospostales`.`nombremunicipio` AS `nombremunicipio`, `codigospostales`.`codigopostal` AS `codigopostal`, `provincias`.`provincia` AS `provincia` FROM ((`clientes` left join `codigospostales` on(`clientes`.`codigopostal` = `codigospostales`.`codigopostal`)) left join `provincias` on(`codigospostales`.`idprovincia` = `provincias`.`codigo`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `totales_pedidos`
--
DROP TABLE IF EXISTS `totales_pedidos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `totales_pedidos`  AS SELECT `pedidos`.`Identificador` AS `Número de pedido`, `pedidos`.`fecha` AS `Fecha del pedido`, `clientes`.`nombre` AS `Nombre del cliente`, sum(`productos`.`precio` * `lineaspedido`.`cantidad`) AS `Total` FROM (((`pedidos` left join `clientes` on(`pedidos`.`clientes_nombre` = `clientes`.`Identificador`)) left join `lineaspedido` on(`lineaspedido`.`pedidos_fecha` = `pedidos`.`Identificador`)) left join `productos` on(`lineaspedido`.`productos_nombre` = `productos`.`Identificador`)) GROUP BY `clientes`.`Identificador` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`Identificador`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`Identificador`);

--
-- Indices de la tabla `codigospostales`
--
ALTER TABLE `codigospostales`
  ADD PRIMARY KEY (`Identificador`);

--
-- Indices de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  ADD PRIMARY KEY (`Identificador`);

--
-- Indices de la tabla `lineaspedido`
--
ALTER TABLE `lineaspedido`
  ADD PRIMARY KEY (`Identificador`),
  ADD KEY `pedidos_fecha` (`pedidos_fecha`),
  ADD KEY `productos_nombre` (`productos_nombre`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`Identificador`),
  ADD KEY `clientes_nombre` (`clientes_nombre`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`Identificador`),
  ADD KEY `categorias_nombre` (`categorias_nombre`);

--
-- Indices de la tabla `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`Identificador`);

--
-- Indices de la tabla `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`Identificador`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Identificador`),
  ADD UNIQUE KEY `Identificador` (`Identificador`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `Identificador` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `Identificador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `codigospostales`
--
ALTER TABLE `codigospostales`
  MODIFY `Identificador` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  MODIFY `Identificador` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `lineaspedido`
--
ALTER TABLE `lineaspedido`
  MODIFY `Identificador` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `Identificador` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2024009;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `Identificador` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `provincias`
--
ALTER TABLE `provincias`
  MODIFY `Identificador` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de la tabla `registros`
--
ALTER TABLE `registros`
  MODIFY `Identificador` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `Identificador` int(10) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `lineaspedido`
--
ALTER TABLE `lineaspedido`
  ADD CONSTRAINT `lineaspedido_ibfk_1` FOREIGN KEY (`pedidos_fecha`) REFERENCES `pedidos` (`Identificador`),
  ADD CONSTRAINT `lineaspedido_ibfk_2` FOREIGN KEY (`productos_nombre`) REFERENCES `productos` (`Identificador`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`clientes_nombre`) REFERENCES `clientes` (`Identificador`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`categorias_nombre`) REFERENCES `categorias` (`Identificador`);

DELIMITER $$
--
-- Eventos
--
CREATE DEFINER=`root`@`localhost` EVENT `Actualizar Evento Provincia` ON SCHEDULE EVERY 1 MINUTE STARTS '2024-06-04 16:45:51' ON COMPLETION NOT PRESERVE ENABLE DO CALL ActualizarCodigoProvincia$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
