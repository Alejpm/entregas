<?php

    // Estructuras de control de bucle
    for($i = 0;$i<=30;$i++){
        echo "Que sepas que hoy es el dia ".$i."del mes<br>";
    }
    $dia = 1;
    while($dia < 30){
        echo "Hoy es el dia ".$dia." del mes <br> ";
        $dia++;
    }

    $dia = 44;
    do{echo "hola"}while($dia < 30);

?>