<?php

    function diHola($nombre){
        echo "Hola ".$nombre." como estas<br>";
    }

    
    diHola("Jose Vicente");
    diHola("Javier");

?> 