<?php
echo "Que sepas que el usuario que has enviado es
    ".$_POST['usuario']."<br>";
echo "Que sepas que el usuario que has enviado es
    ".$_POST['password']."<br>";
// Abro la base de datos
$enlace = mysqli_connect("localhost", "cursoaplicacionesweb", "cursoaplicacionesweb", "cursoaplicacionesweb");
// Le pido algo a la base de datos
$peticion = " 

INSERT INTO usuarios
VALUES(NULL,
    '".$_POST['usuario']."',
    '".$_POST['password']."',
    '".$_POST['nombre']."',
    '".$_POST['apellidos']."',
    '".$_POST['email']."',
    '".$_POST['direccion']."',
    '".$_POST['telefono']."')


 
";
mysqli_query($enlace,$peticion );
echo $peticion."<br>";
// Cierro los recursos que haya abierto
mysqli_close($enlace);

echo "El registro se ha metido en la base de datos"; 

?>