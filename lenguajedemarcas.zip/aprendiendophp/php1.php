<p>Un archivo PHP puede contener html</p>

<?php

    //Comentario de una línea
    /*
        Esto es un comentario
        de varias
        líneas
    */

    echo "Esto es algo de html desde php";

?>