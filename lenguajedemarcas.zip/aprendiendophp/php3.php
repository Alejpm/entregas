<?php

    $o1 = 4;
    $o2 = 3;
    $o = "3";

    echo "La suma de los operadores es ".($o1+$o2)."<br>"; 
    echo "La resta de los operadores es ".($o1-$o2)."<br>";
    echo "La multiplicacion de los operadores es ".($o1*$o2)."<br>";
    echo "La division de los operadores es ".($o1/$o2)."<br>";
    echo "El resto entero de los operadores es ".($o1%$o2)."<br>";

    echo "Es cierto que los dos operandos son iguales? ".($o2 == $o3)."<br>";
    echo "Es cierto que los dos operandos son exactamente iguales? ".($o2 === $o3)."<br>";
    echo "Es cierto que los dos operandos NO son iguales? ".($o1 != $o2)."<br>";

    $dia = "miercoles";
    $mes = "agosto";

    echo "Es cierto que las dos son ciertas ".($dia == "miercoles" && $mes == "agosto")."<br>";
    echo "Es cierto que las dos son ciertas ".($dia == "miercoles" && $mes == "octubre")."<br>";
    echo "Es cierto que alguna de las dos son ciertas ".($dia == "miercoles" || $mes == "octubre")."<br>";
    echo "Es cierto que alguna de las dos son ciertas ".($dia == "martes" || $mes == "octubre")."<br>";

?>