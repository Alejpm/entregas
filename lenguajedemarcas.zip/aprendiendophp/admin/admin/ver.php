<?php
    $peticion = "SELECT * FROM examen
    WHERE Identificador = ".$_GET['id']."
    ";
    $resultado = mysqli_query($enlace,$peticion );
     while ($fila = $resultado->fetch_assoc()) {
       echo '
       titulo '.$fila['titulo'].'<br>
       contenido '.$fila['contenido'].'<br>
       autor_id: '.$fila['autor_id'].'<br>
        '; 
 
 }


?> 
