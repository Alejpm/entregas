<?php

session_start();
// Abro la base de datos
$enlace = mysqli_connect("localhost", "cursoaplicacionesweb", "cursoaplicacionesweb", "cursoaplicacionesweb");
// Le pido algo a la base de datos
$peticion = " 
SELECT * FROM usuarios
WHERE
usuario = '".$_POST['usuario']."'
AND
password = '".$_POST['password']."'
";

$resultado = mysqli_query($enlace,$peticion );

$pasas = false; 


 if ($fila = $resultado->fetch_assoc()) {
    // echo $fila['nombre']." ".$fila['apellidos']."<br>";
     $pasas = true;
     $_SESSION['nombre'] = $fila['nombre'];
     $_SESSION['apellidos'] = $fila['apellidos']; 

     
 }else{
    //echo "No hay ningun usuario que cumpla esas caracteristicas";
     $pasas = false;
 }

if($pasas){
    echo "Te voy a dar acceso a la aplicacion";
    $_SESSION['pasas'] = true;
    echo '<meta http-equiv="refresh" content="5; url=paneldecontrol.php">';
}else{
    $_SESSION['pasas'] = false;
    echo "No te voy a dar acceso a la aplicacion";
    echo '<meta http-equiv="refresh" content="5; url=index.html">';
}



mysqli_close($enlace);
?>