<?php

    $enlace = mysqli_connect("localhost", "examen", "examen", "examen");

?>