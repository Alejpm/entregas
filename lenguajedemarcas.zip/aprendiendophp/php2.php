<?php

    $edad = 42;
    $nombre = "Jose Vicente";

    echo "Mi nombre es".$nombre." y mi edad es ".$edad;

?>