
package proyectojava11;


public class Proyectojava11 {

    
    public static void main(String[] args) {
        int dia = 100;
        do{
           System.out.println("Hoy es el dia "+dia+" del mes y lo que tienes que hacer es: ");
           dia++;
        }while(dia < 30);

    }
    
}
