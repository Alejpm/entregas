package proyectojava16;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
        
public class Proyectojava16x {

    public static void main(String[] args) throws FileNotFoundException { 
        
        try{
        
            try (FileWriter miarchivo = new FileWriter("archivo.txt")) {
                miarchivo.write("Hola que sepas que esto se ha escrito desde Java");
            }
  
    }catch(IOException e){
}         
        try{
        File miotroarchivo = new File("archivo2.txt");
        Scanner lector = new Scanner(miotroarchivo);
        while(miotroarchivo.hasNextLine()){
            System.out.println(lector.nextLine());
        }
    }
    catch()static {
}
}
