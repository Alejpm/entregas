package sqlite;

import java.sql.*;

/**
 *
 * @author Alejandro
 */
public class SQLite {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola SQLite");
        Connection conexion = null;
        // Declaro las variables en las que guardo la informacion
            int windows = 0;
            int mac = 0;
            int ubuntu = 0;
            int android = 0;
            int iOS = 0;  
            String nwindows = "";
            String nmac = "";
            String nubuntu = "";
            String nandroid = "";
            String nios = "";
            
        try{
            String ruta = "jdbc:sqlite:C:\\Users\\Alejandro\\Desktop\\sqliteregistros\\registros.db";
            conexion = DriverManager.getConnection(ruta);     
            
            Statement peticion = conexion.createStatement();
            // Pido cosas a la base de datos
            // Windows
                String consulta = "SELECT * FROM visitaswindows";
                ResultSet resultados = peticion.executeQuery(consulta);
                while(resultados.next()){windows = resultados.getInt("windows");}
            // mac
                consulta = "SELECT * FROM visitasmac";
                resultados = peticion.executeQuery(consulta);
                while(resultados.next()){mac = resultados.getInt("windows");}
            // Ubuntu
                consulta = "SELECT * FROM visitasubuntu";
                resultados = peticion.executeQuery(consulta);
                while(resultados.next()){ubuntu = resultados.getInt("windows");}
            // Android
                consulta = "SELECT * FROM visitasandroid";
                resultados = peticion.executeQuery(consulta);
                while(resultados.next()){android = resultados.getInt("windows");}
            // iOS
                consulta = "SELECT * FROM visitasios";
                resultados = peticion.executeQuery(consulta);
                while(resultados.next()){iOS = resultados.getInt("windows");}
                
                /*
                for(int i = 0;1<windows;i+1000){nwindows += "#";}
                for(int i = 0;1<mac;i+1000){nmac += "#";}
                for(int i = 0;1<ubuntu;i+1000){nubuntu += "#";}
                for(int i = 0;1<android;i+1000){nandroid += "#";}
                for(int i = 0;1<iOS;i+1000){nios += "#";}
                */
            System.out.println("Windows:\t\t"+String.valueOf(windows)+" "+nwindows);
            System.out.println("Mac:\t\t"+String.valueOf(mac)+" "+nmac);
            System.out.println("Ubuntu:\t\t"+String.valueOf(ubuntu)+" "+nubuntu);
            System.out.println("Android:\t\t"+String.valueOf(android)+" "+nandroid);
            System.out.println("iOS:\t\t"+String.valueOf(iOS)+" "+nios);
        }catch(SQLException e){
        System.out.println(e.getMessage());}
    }
}

