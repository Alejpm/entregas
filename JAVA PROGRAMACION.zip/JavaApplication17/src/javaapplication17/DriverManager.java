/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication17;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Alejandro
 */
class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306cursoprueba, String cursojava, String cursojava0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
