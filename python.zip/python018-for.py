# for(int i = 1;i<=19;i++){

for i in range(1,10):
    print("esta es la linea",i)

print("Si ves esto, es que ya no estamos en el bucle for")
