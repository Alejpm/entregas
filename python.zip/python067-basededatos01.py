import mysql.connector as my
try:
    mibd = my.connect(
    host = "127.0.0.1",
    user = "alejandro",
    password = "alejandro",
    database = "cursopython"
    )

##print(mibd)

    micursor = mibd.cursor()
    
    micursor.execute("SELECT COUNT(Nombre) AS cuenta, Nombre FROM Alumnos GROUP
    miresultado = micursor.fetchall()

    labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
sizes = [15, 30, 45, 10]
explode = (0,0.1,0,0)

    for i in miresultado:
            print("tengo un resultado que es:")
            print(str(i[1])+" - "+str(i[0])
            sizes.append(i[0]))
            labels.append(i[1])

labels = "hola",##NOMBRES

print("vamos a comprobar")
print(labels)
print(sizes)
print("quiero ver el tipo de dato")
print(type(labels))

fig1, ax1 = plt.subplots()
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90)
ax1.axis('equal')

plt.show()



