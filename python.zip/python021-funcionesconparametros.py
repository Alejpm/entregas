#def saludaMe():
#    print("Bienvenido quien seas")
    
def saludaMe(nombre,edad):
    print("Bienvenido,",nombre, "y tu edad es de",edad,"años")


saludaMe("Alejandro",19)
saludaMe("Juan",40)
