'''
Puedes escribir lo que quieras
lo que quieras
fasdf
adsfa
sfd
sfd
dsfafd
dasfa
fd
f

'''

print("Esto es el programa en si mismo")

