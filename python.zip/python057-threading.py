import threading
import time

def trabajador(numero):
    print("hola soy un trabajador numero %s \n" % numero )
    time.sleep(1/(numero+1))
    trabajador(numero)

tareas = []

for i in range(5):
    t = threading.Thread(target = trabajador,args=(i,))
    tareas.append(t)
    t.start()







#2143
#1243
#2134
