from tkinter import *

f = Frame(width=300,height=300)
f.pack(padx=30,pady=30)

titulo = Label(f,text = "Hola Alejandro")
titulo.pack(side=TOP)
