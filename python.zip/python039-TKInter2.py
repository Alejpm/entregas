from tkinter import *

def saluda():
    print("Has pulsado un boton")
    


marco = Frame(width=300,height=300,bg="#b8cd2b")
marco.pack(padx=30,pady=30)

titulo = Label(marco,text="Programa agenda v0.1",fg="black",font=("Arial,Verdana,sans-serif",24))
titulo.pack(side=TOP)

autor = Label(marco,text="Alejandro Porter",fg="grey",font=("Arial,Verdana,sans-serif",16))
autor.pack(side=TOP)

foto = PhotoImage(file="python.png",width=333,height=333)

textofoto = Label(marco,image=foto)
textofoto.pack(side=TOP)

boton = Button(marco,text="Pulsame",command=saluda)
boton.pack(side=TOP,padx=10,pady=10)


mainloop()
