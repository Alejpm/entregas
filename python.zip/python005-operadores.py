edad = 19
print("Que sepas que tienes",(edad+5),"años")

edad = edad *2
print("Y ahora la edad es ",edad)
