edad = 25
if edad < 20:
    if edad < 10:
        print("Eres un niño")
    else:
        print("Eres un adolescente")

else:
    if edad < 30:
        print("Eres un joven")
    else:
        print("definitivamente se te ha acabado lo bueno")
