class CuentaBancaria:
    def __init__(self,numero,nombre,saldo):
        self.numero = numero
        self.nombre = nombre
        self.saldo = saldo
    def modificaSaldo():
        asdfasfdasfdfsad

cuenta1 = CuentaBancaria("0001","Alejandro Porter",1000)

print(cuenta1.saldo)
cuenta1.saldo = 100000000000
print(cuenta1.saldo)
