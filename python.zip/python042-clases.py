##Esto es la definición de una clase
class Persona:
    nombre = "Juan"
    
##Y ahora convertimos una clase en un objeto
persona1 = Persona()
persona1.nombre = "Jorge"
print(persona1.nombre)

persona2 = Persona()
persona2.nombre = "Jaime"
print(persona2.nombre)
    
    
