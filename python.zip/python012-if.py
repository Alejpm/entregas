print("Dime tu nombre")
nombre = input()
#A continuacion quiero ver si el sistema guarda esa informacion
print("Hola,",nombre)

print("Dime tu edad")
edad = input()
print("Tu nombre es",nombre,",Tu edad es de",edad,"años")

edad = 15

if edad < 30:
    print("Eres una persona joven")
else:
    print("Ya no eres tan joven como antes")
    print("Que sepas que esto esta dentro del else")

print("esto se va a ejecutas si o si")
