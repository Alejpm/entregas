import mimodulo

mivariable = dir(mimodulo)
print(mivariable)
