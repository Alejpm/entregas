import mimodulo as mm

mm.dimeHola()
mm.dimeAdios()
