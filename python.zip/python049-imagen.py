from tkinter import *
import PIL

marco = Frame(width=300,height=300)
marco.pack(padx=30,pady=30)

lienzo = Canvas()

imagen = Image.open

lienzo.pack(side=TOP)
