edad = 19

print("Que sepas que tienes",edad,"años")
