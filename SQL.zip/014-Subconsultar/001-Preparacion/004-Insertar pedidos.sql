INSERT INTO `pedidos` (`Identificador`, `clientes_id`, `fecha`, `total`) VALUES (NULL, '1', '2024-02-22', '2000');
INSERT INTO `pedidos` (`Identificador`, `clientes_id`, `fecha`, `total`) VALUES (NULL, '2', '2024-02-22', '4000');
INSERT INTO `pedidos` (`Identificador`, `clientes_id`, `fecha`, `total`) VALUES (NULL, '2', '2024-02-22', '1000');
INSERT INTO `pedidos` (`Identificador`, `clientes_id`, `fecha`, `total`) VALUES (NULL, '3', '2024-02-22', '1000');
INSERT INTO `pedidos` (`Identificador`, `clientes_id`, `fecha`, `total`) VALUES (NULL, '4', '2024-02-22', '2000');