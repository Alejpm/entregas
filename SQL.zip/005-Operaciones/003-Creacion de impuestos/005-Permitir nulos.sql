ALTER TABLE pedidos
ADD COLUMN impuestos_nombre INT(10) NOT NULL,
ADD FOREIGN KEY (impuestos_nombre) REFERENCES impuestos(Identificador);

ALTER TABLE `pedidos` ADD `impuestos_nombre` INT(255) NOT NULL AFTER `clientes_nombre`;