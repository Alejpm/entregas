INSERT INTO `impuestos`(`Identificador`, `nombre`, `tipoimpositivo`, `descripcion`) VALUES (NULL,'IVA 21%',21,'IVA general');
INSERT INTO `impuestos`(`Identificador`, `nombre`, `tipoimpositivo`, `descripcion`) VALUES (NULL,'IVA 10%',10,'IVA reducido');
INSERT INTO `impuestos`(`Identificador`, `nombre`, `tipoimpositivo`, `descripcion`) VALUES (NULL,'IVA 4%',4,'IVA super reducido');
INSERT INTO `impuestos`(`Identificador`, `nombre`, `tipoimpositivo`, `descripcion`) VALUES (NULL,'IVA 0%',0,'IVA exento');