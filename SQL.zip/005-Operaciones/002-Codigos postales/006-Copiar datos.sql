UPDATE
codigospostales
SET idprovincia = LEFT(codigopostal,2);