UPDATE codigospostales
SET codigopostal = LPAD(codigopostal,5,'0');