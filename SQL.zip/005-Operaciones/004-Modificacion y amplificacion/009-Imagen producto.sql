ALTER TABLE `productos` CHANGE `imagen` `imagen` MEDIUMBLOB NOT NULL;
