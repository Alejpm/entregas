UPDATE pedidos
SET pagado = 100;
