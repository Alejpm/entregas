DELIMITER //

CREATE TRIGGER insertar_pedido
AFTER INSERT ON pedidos	
FOR EACH ROW
BEGIN
	INSERT INTO registros VALUES(NULL,'INSERT',NOW(),'pedidos',NEW.Identificador,USER());
END;

//
DELIMITER ;