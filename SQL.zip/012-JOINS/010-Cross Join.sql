SELECT * FROM
alumnos
CROSS JOIN matriculas;

// Muestra todas las posibilidades de conexion entre tablas...