SELECT * 
FROM alumnos 
LEFT JOIN matriculas 
ON alumnos.nombre = matriculas.alumno;