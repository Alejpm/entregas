INSERT INTO `asignaturas` (`Identificador`, `nombre`, `alumno`, `fecha`) VALUES (NULL, 'bases de datos', 'julia', '2024-02-22');
INSERT INTO `asignaturas` (`Identificador`, `nombre`, `alumno`, `fecha`) VALUES (NULL, 'bases de datos', 'jorge', '2024-02-22');
INSERT INTO `asignaturas` (`Identificador`, `nombre`, `alumno`, `fecha`) VALUES (NULL, 'bases de datos', 'javier', '2024-02-22');