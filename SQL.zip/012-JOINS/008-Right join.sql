SELECT * 
FROM alumnos 
RIGHT JOIN matriculas 
ON alumnos.nombre = matriculas.alumno;