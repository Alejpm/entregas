CREATE DATABASE centrodeformacion;
USE centrodeformacion;