SELECT * 
FROM alumnos 
INNER JOIN matriculas 
ON alumnos.nombre = matriculas.alumno;