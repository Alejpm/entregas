INSERT INTO `categorias` (`Identificador`, `nombre`,
`pariente`) VALUES (NULL, 'informática', '');

INSERT INTO `categorias` (`Identificador`, `nombre`,
`pariente`) VALUES (NULL, 'informática', '1');

INSERT INTO `categorias` (`Identificador`, `nombre`,
`pariente`) VALUES (NULL, 'informática', '1');

INSERT INTO `categorias` (`Identificador`, `nombre`,
`pariente`) VALUES (NULL, 'DAM', '2');

INSERT INTO `categorias` (`Identificador`, `nombre`,
`pariente`) VALUES (NULL, 'DAW', '2');