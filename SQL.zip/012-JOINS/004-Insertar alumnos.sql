INSERT INTO `alumnos` (`Identificador`, `nombre`) VALUES 
(NULL, 'juan');
INSERT INTO `alumnos` (`Identificador`, `nombre`) VALUES 
(NULL, 'jorge');
INSERT INTO `alumnos` (`Identificador`, `nombre`) VALUES 
(NULL, 'julia');
INSERT INTO `alumnos` (`Identificador`, `nombre`) VALUES 
(NULL, 'jose vicente');