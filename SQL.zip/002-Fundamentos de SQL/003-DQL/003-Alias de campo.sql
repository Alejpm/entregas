SELECT 
    nombre AS 'Nombre del cliente',
    idfiscal AS 'Identificacion fiscal',
    direccion AS 'Direccion del cliente',
    codigopostal AS 'Codigo postal'
FROM clientes;