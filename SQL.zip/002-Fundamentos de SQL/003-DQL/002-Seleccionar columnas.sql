SELECT 
    nombre,
    idfiscal,
    direccion,
    codigopostal
FROM clientes;