INSERT INTO `lineaspedido` (`Identificador`, `pedidos_fecha`, `productos_nombre`, `cantidad`) 
VALUES (NULL, '2', '10', '2');
INSERT INTO `lineaspedido` (`Identificador`, `pedidos_fecha`, `productos_nombre`, `cantidad`) 
VALUES (NULL, '2', '5', '3');
INSERT INTO `lineaspedido` (`Identificador`, `pedidos_fecha`, `productos_nombre`, `cantidad`) 
VALUES (NULL, '2', '6', '2');