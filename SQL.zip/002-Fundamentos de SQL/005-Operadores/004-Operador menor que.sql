SELECT * 
FROM productos
WHERE precio < 100;