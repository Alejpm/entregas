SELECT * 
FROM productos
WHERE precio <= 200.50 