SELECT * 
FROM productos
WHERE precio != 15.50;