SELECT * 
FROM productos
WHERE 
nombre LIKE 'Curso%';