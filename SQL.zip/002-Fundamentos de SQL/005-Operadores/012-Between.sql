SELECT * 
FROM productos
WHERE 
precio BETWEEN 10 AND 100