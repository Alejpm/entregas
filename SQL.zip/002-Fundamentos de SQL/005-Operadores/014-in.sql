SELECT * 
FROM productos
WHERE 
nombre IN ('Ratón','Teclado');