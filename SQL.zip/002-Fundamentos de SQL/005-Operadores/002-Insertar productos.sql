INSERT INTO productos VALUES(
    NULL,
    'Ratón',
    'Ratón de ordenador',
    15.50,
    'fisico',
    '0,1',
    'raton.jpg'
);
INSERT INTO productos VALUES(
    NULL,
    'Teclado',
    'Teclado de ordenador',
    20.50,
    'fisico',
    '0,2',
    'teclado.jpg'
);
INSERT INTO productos VALUES(
    NULL,
    'Monitor',
    'Monitor de ordenador',
    200.50,
    'fisico',
    '2',
    'monitor.jpg'
);
INSERT INTO productos VALUES(
    NULL,
    'Curso',
    'Curso de SQL paso a paso',
    300.50,
    'virtual',
    0,
    'cursosql.jpg'
);
INSERT INTO productos VALUES(
    NULL,
    'Curso de PHP',
    'Curso de PHP paso a paso',
    200.50,
    'virtual',
    0,
    'cursophp.jpg'
);
INSERT INTO productos VALUES(
    NULL,
    'Curso de Python',
    'Curso de Python paso a paso',
    400.50,
    'virtual',
    0,
    'cursopython.jpg'
);