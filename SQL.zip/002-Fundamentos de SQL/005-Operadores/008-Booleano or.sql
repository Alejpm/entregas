SELECT * 
FROM productos
WHERE 
precio > 100
OR
categoria = 'fisico';
