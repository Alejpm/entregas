SELECT * 
FROM productos
WHERE 
precio > 20
AND
precio < 100;