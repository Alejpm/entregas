SELECT * 
FROM productos
WHERE 
not LIKE 'Curso%';