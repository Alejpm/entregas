SELECT * 
FROM productos
WHERE 
nombre = "Ratón"
OR
nombre = "Teclado";