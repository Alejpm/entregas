INSERT INTO pedidos	
VALUES(
    NULL,
    '2023-20-12',
    3
);