INSERT INTO clientes 

VALUES
(
    'Nombre de la empresa 2',
    'C000002',
    'Dirección de la empresa 2',
    '46002'
);