DELETE FROM clientes;
WHERE Identificador = 4;