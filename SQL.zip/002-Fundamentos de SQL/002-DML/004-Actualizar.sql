UPDATE clientes	
SET nombrepersonacontacto = 'Jorge Martinez García',
emailpersonacontacto = 'jorgemartinez@empresa2.com'
;