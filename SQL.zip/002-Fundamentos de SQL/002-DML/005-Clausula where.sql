UPDATE clientes	
SET 
nombrepersonacontacto = 'Jose Lopez',
emailpersonacontacto = 
'joselopez@empresa1.com'
WHERE
Identificador = 1;
