INSERT INTO clientes VALUES(
    NULL,
    'Nombre de la empresa 1',
    'C000001',
    'Dirección de la empresa 1',
    '46001',
    'Juan Lopez Martinez',
    'juanlopez@empresa1.com',
    'logoempresa1.jpg'
);