INSERT INTO clientes 
(
    nombre,
    idfiscal,
    direccion,
    codigopostal
)
VALUES
(
    'Nombre de la empresa 2',
    'C000002',
    'Dirección de la empresa 2',
    '46002'
);