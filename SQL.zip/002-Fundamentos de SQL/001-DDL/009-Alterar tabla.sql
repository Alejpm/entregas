ALTER TABLE 
`usuarios` 
ADD 
`fotografia` 
VARCHAR(100) NOT NULL AFTER `telefono`;
