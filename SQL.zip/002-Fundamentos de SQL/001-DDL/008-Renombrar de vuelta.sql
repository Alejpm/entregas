RENAME TABLE
`empresa`.`misusuarios`
TO
`empresa`.`usuarios`;