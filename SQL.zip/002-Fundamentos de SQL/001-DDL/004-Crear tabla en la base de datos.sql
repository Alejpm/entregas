CREATE TABLE `empresa`.`usuarios` 
    (`Identificador` INT NOT NULL , 
    `nombre` INT NOT NULL , 
    `contrasena` INT NOT NULL , 
    `nombrepropio` INT NOT NULL , 
    `apellidos` INT NOT NULL , 
    `email` INT NOT NULL , 
    `telefono` INT NOT NULL , 
    PRIMARY KEY (`Identificador`)
) 
ENGINE = InnoDB;
COMMENT = 'En esta tabla guardaremos los usuarios';