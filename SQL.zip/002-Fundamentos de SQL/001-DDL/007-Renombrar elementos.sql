RENAME TABLE
`empresa`.`usuarios`
TO
`empresa`.`misusuarios`;