mysqldump.exe -u alejandro -p --all-databases > 
C://copiasdeseguridad//20240604copiadeseguridad.sql
