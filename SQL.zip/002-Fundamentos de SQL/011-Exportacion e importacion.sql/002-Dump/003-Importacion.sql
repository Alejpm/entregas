mysql.exe -u empresa2 -p empresa2 <
C://copiasdeseguridad//20240604empresa.sql

/por hacer