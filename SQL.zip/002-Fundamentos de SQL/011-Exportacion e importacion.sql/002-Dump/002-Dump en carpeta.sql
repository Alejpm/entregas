mysqldump.exe -u empresa -p empresa > empresa.sql >
C://copiasdeseguridad//20240604empresa.sql

/POR HACER