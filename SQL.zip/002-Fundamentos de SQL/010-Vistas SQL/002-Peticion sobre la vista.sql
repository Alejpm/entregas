SELECT * FROM `totales_pedidos` 
ORDER BY 'Total' DESC; 