GRANT ALL 
PRIVILEGES ON 
`empresa`.* 
TO 
'alejandro'@'%';