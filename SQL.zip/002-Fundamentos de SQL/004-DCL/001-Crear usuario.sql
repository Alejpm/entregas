CREATE USER 
'alejandro'@'%' 
IDENTIFIED VIA 
mysql_native_password 
USING '***';
