
package proyectojava6;


public class Proyectojava6 {

    
    public static void main(String[] args) {
        int edad1 = 42;
        int edad2 = 25;
        int maximo = Math.max(edad1,edad2); //Coge el número máximo
        System.out.println("El maximo es:"+maximo);
        double numero = 45.2;
        double redondeo = Math.floor(numero); //Double redondea //Floor el mas bajo  //Ceil al mas alto
        System.out.println("El maximo es:"+redondeo);
        double angulo = Math.PI;
        double seno = Math.sin(angulo);
        double coseno = Math.cos(angulo);
        System.out.println("El coseno es: "+coseno);
    }
    
}
