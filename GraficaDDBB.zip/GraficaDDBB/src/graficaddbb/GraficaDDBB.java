package graficaddbb;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;


public class GraficaDDBB extends JPanel{

 
    @Override public void paint(Graphics g){
        super.paint(g);
        Graphics2D misgraficos = (Graphics2D) g;
        int basegrafica = 360;
        misgraficos.drawLine(10, 10, 10, 360);                      // Linea vertical
        misgraficos.drawLine(10, basegrafica, 360, basegrafica);    // Linea horizontal
        int[] barras = new int[]{ 200,300,200,200,100,200,50,200,25,50,100};
        
        //////////////////////////////////////////////////////////////// ME CONECTO A LA BASE DE DATOS Y SACO DATOS
        
            String url = "jdbc:sqlite:C:\\Users\\Alejandro\\Desktop\\sqliteregistros\\registros.db";
        Connection conn = null;
        try {
            String sql = "SELECT * FROM logmeses";
            conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs   = stmt.executeQuery(sql);
            int contador = 0;
            while (rs.next()) {
                System.out.println(rs.getInt("mes") + "\t" +
                                   rs.getString("numero"));  
                //////////////////////////////////////////////////////////////// COJO OLS DATOS DE LA BASE DE DATOS Y LOS METO EN UNA MATRIZ
            barras[contador] = Integer.parseInt(rs.getString("numero"))/10;
            contador++;
            }       
        }  catch (SQLException e) {
                System.out.println(e.getMessage());
        }
           String sql = "SELECT * FROM logmeses;";
                
        //////////////////////////////////////////////////////////////// PINTO LOS DATOS DE LA BASE DE DATOS 
        for(int i = 0;i<barras.length;i++){
           // int randomNum = ThreadLocalRandom.current().nextInt(10, 300 + 1);
           int randomNum = barras[i];
            misgraficos.fillRect(i*30+20, basegrafica-randomNum, 20, randomNum);  
                
        }
                 // Dibujo una primera barrap`'
    }
    public static void main(String[] args) {
        // TODO code application logic here
        JFrame marco = new JFrame("grafica");
        GraficaDDBB mimarco = new GraficaDDBB();
        marco.add(mimarco);
        marco.setSize(400,400);
        marco.setVisible(true);
        marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
