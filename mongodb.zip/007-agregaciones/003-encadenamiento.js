db.productos.aggregate(
    [ 
      // Fase 1 de la agregacion      
      {
            $group:{
                _id:"$precio"
            }
        },
        //Fase 2 de la agregacion
         {
            $limit:1
         }
    ]   
);