db.productos.find(
    {
        
        $nor: [
            {
                producto:"producto 1"
            },
            {
                precio:45
            }
        ]
    }
);