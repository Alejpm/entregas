db.productos.insertMany(
    [
        {
            nombre:"producto 1",
            precio:15,
            descripcion:"Esta es la descripcion para el producto 1"
        },
          {
            nombre:"producto 2",
            precio:35,
            descripcion:"Esta es la descripcion para el producto 2"
        },
          {
            nombre:"producto 3",
            precio:25,
            descripcion:"Esta es la descripcion para el producto 3"
        },
          {
            nombre:"producto 4",
            precio:55,
            descripcion:"Esta es la descripcion para el producto 4"
        },
          {
            nombre:"producto 5",
            precio:65,
            descripcion:"Esta es la descripcion para el producto 5"
        }
    ]
)