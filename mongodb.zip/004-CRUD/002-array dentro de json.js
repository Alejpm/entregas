db.clientes.insertOne({
    nombre:"Juan",
    apellidos:"Garcia",
    telefono:"+34 24324253254",
    email:"info@juan.com",
    direciones:[
        "direccion 1",
        "direccion 2"
    ]
})