db.clientes.updateMany(
    {nombre:'Jose Vicente'},
    {
        $set:
        {email:"11111111"}
    }
)