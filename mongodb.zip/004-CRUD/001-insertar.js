db.clientes.insertOne({
    nombre:"Jose Vicente",
    apellidos:"Carratala",
    telefono:"+34 555512345",
    email:"info@josevicentecarratala.com"
})