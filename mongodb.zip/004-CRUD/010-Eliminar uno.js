db.clientes.deleteOne(
    {nombre:'Jose Vicente'}
)
    