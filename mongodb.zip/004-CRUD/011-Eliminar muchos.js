db.clientes.deleteMany(
    {email:'info@juan.com'}
)
    