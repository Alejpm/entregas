db.clientes.insertMany(
    [
    {
        nombre:"Jorge",
        apellidos:"Garcia",
        telefono:"+34 5234345",
        email:"info@juan.com"
},
    {
        nombre:"Jose",
        apellidos:"Lopez",
        telefono:"+34 24312345",
        email:"info@jose.com"
},
    {
        nombre:"Julia",
        apellidos:"Martinez",
        telefono:"+34 55542234",
        email:"info@julia.com"
},
        ]
)
    