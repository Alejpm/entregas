#include <stdio.h>

int main(int argc,char *argv[]){
    int numero1 = 4;
    int numero2 = 4;
    int resultado = numero1 == numero2;
    printf("El resultado de la operación es: %i \n",resultado);
    
    return 0;



}