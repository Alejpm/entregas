<?php

$imagen = imagecreatetruecolor(400,300);

$fondo = imagecolorallocate($imagen, 255, 255, 255);

$col_elipse = imagencolorallocate($imagen, 255, 255, 255);

imagefilledellipse($imagen, 200, 150, 300, 200, $col_elipse);

header("Content-type: image/png");
imagepng($imagen);

?>