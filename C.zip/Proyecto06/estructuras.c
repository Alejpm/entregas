#include <stdio.h>

int main(int argc,char *argv[]){
    int edad = 42;
    if(edad == 40)[
        // Esto se ejecuta en el caso verdadero
        printf("Es cierta la afirmación");      
    ]else{
        // Esto se ejecuta en el caso falso
        printf("La afirmación no es cierta");
        
    }
    return 0;
    
    }