#include <stdio.h>

int main(int argc,char *argv[]){
    char* agenda[10][4;]
    
    agenda[0][0] = "Alejandro";
    agenda[0][1] = "12345";
    agenda[0][2] = "La calle de Alejandro";
    agenda[0][3] = "alejandro@email.com";
    
     
    agenda[1][0] = "Juan";
    agenda[1][1] = "23456";
    agenda[1][2] = "La calle de Juan";
    agenda[1][3] = "juan@email.com";
    
     
    agenda[2][0] = "Jaime";
    agenda[2][1] = "34567";
    agenda[2][2] = "La calle de Jaime";
    agenda[2][3] = "jaime@email.com";
    
    printf("La calle de Alejandro es %s \n",agenda[0][2]);
    
    
    
    printf("\n");
    return 0;
}